## V1.0.0 3 Nov, 2016
### Initial Release

## V1.1.0 17 Nov, 2016
### BugFixing, Plugin Change
  - Fix bug on main panel > content while you use the Sidebar Mini
  - Replaced select plugin with a more complex select “bootstrap-select”
  - Added File Input library by Jasny
  - change filter colors for example pages
  - fix Charts responsive issue when switching from Desktop to Mobile
  - added PerfectScrollbar just for Windows, fix problem in MacOs and Ubuntu

## V1.2.0 8 Sep, 2017
### BugFixing, Plugin Change
  - Added a new Sidebar-menu ( the old one was replaced ) and a new color for the Sidebar-menu 'red' with 'white' as the active color
  - Plugins that were updated to the latest versions:
    - jquery.min.js 3.2.1
    - es6-promise-auto.min.js 4.1.1
    - noUiSlider.min.js 10.0.0
    - chartist.min.js 0.11.0
    - fullcalendar.min.js 3.5.0
    - jquery.bootstrap-wizard.js 1.4.2
    - jquery.select-bootstrap.js 1.12.2
  - Added Arrive.js library  for elements that are inserted dinamically
  - Removed jquery.mobile-1.4.5.min.js library because this it's not compatible with jquery 3+
  - Added version in CSS and JS links
  - Bug Fixes
  - Moved Documentation online for better update
